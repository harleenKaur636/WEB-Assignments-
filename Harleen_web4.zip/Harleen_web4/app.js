const express = require('express')
const app = express()

const bodyParser = require('body-parser')

const request = require('request')


app.use(bodyParser.urlencoded({extended:true}))

app.set('view engine','ejs')

app.get('/',(req,res)=>{

    res.render('form.ejs')
})

app.post('/data',(req,res)=>{

    const data = req.body

    
    const page = data.page_number
    

    request(`https://api.unsplash.com/photos?client_id=-dBuyP1fMDrlB8jZi_9AyeWpNaum9ZTdD6Rw3V0mLwQ&page=${page}`,(error,response,body)=>{
        let myData = null
    if(error){

     console.log(error)        
    }else{

    console.log(page)    
    console.log(response.statusCode)
    myData = JSON.parse(body)
    console.log(myData)
    res.render('data.ejs',{data:myData})
    }

    })
})


app.listen(2500,()=>{
    console.log("App is listening at port 2500")
})