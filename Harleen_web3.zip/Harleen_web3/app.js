
/********************************************************************************* 
*  WEB322 – Assignment 3 
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.   
*  No part of this assignment has been copied manually or electronically from any other source 
*  (including web sites) or distributed to other students. 
*  
*  Name: _____Harleen Kaur_________________ Student ID: ______163071210________ Date: _______30-11-2022________
********************************************************************************/ 

const express = require('express')

const app = express()

// set the view engine as ejs to use ejs files  

app.set('view engine','ejs')

// body parser is middleware

const bodyParser = require('body-parser')

app.use(bodyParser.urlencoded({extended:true}))

// code for mongo db

const mongoose = require('mongoose')

// "mongodb+srv://harleenkaur:<web322>@cluster0.8brtnui.mongodb.net/?retryWrites=true&w=majority"
// {useNewUrlParser: true}

// set up the connection

mongoose.connect("mongodb+srv://harleenkaur:<web322>@cluster0.8brtnui.mongodb.net/?retryWrites=true&w=majority",{
    useNewUrlParser: true, useUnifiedTopology: true
},(error)=>{
    if(error){
        console.log(error)
    }
console.log("Connected to mongo db!!!!")

})

//Create Schema for employee model

const empsSchema = mongoose.Schema({

    name : String,
    contact : String,
    city : String,
    email : String,
    salary : Number
})

// Create a model for emps collection 

const empsModel = mongoose.model('emp', empsSchema)


// To display our form wwe need a get route

app.get('/insert',(req,res)=>{

    res.render('insert.ejs')
})

app.post('/insert', (req,res)=>{


     // to get the form data out of request body we need body parser
     //require bodyparser and use one of its features before using request body

    const emp_data_from_form = req.body

    console.log(emp_data_from_form)
 
    
    


    // To save data in mongo db we create connection, schema and then model
    //having same fields name,contact,city,email,salary

    empsModel.create({

 name : emp_data_from_form.e_name,
 contact : emp_data_from_form.e_con,
 city : emp_data_from_form.e_city,
 email : emp_data_from_form.e_email,
 salary : emp_data_from_form.e_salary 

    },(error,emp_inserted)=>{
        if(error){
            console.log(error)
        }

        else{
            res.redirect('/all')
        }
    })

})

// Create a route to show all Employees from MongoDb

app.get('/all',(req,res)=>{


    empsModel.find({},(error,all_emps)=>{

        if(error){
            console.log(error)
        }
        else{

            res.render('display.ejs',{data:all_emps})
        }
    })
})

app.get('/edit/:id', (req,res)=>{

    const id_to_edit = req.params.id

    empsModel.findById(id_to_edit,(error,emp_to_edit)=>{

        if(error){

            console.log(error)
        }

        else{

            res.render("edit.ejs",{emp : emp_to_edit})
        }
    })
})

app.post('/edit/:id', (req,res)=>{


    const id = req.params.id

    const updated_emp = req.body

    empsModel.findByIdAndUpdate(id,{
        name : updated_emp.e_name,
        contact : updated_emp.e_con,
        city : updated_emp.e_city,
        email : updated_emp.e_email,
        salary : updated_emp.e_salary

    },(error,updated_emp)=>{

        if (error){

            console.log(error)
        }
        else{
            res.redirect('/all')
        }
    })
})

app.get('/delete/:id',(req,res)=>{

    const id = req.params.id

    empsModel.findByIdAndDelete(id,(error,emp_deleted)=>{


        if(error){
            console.log(error)
        }
        else{
            res.redirect('/all')
        }
    })
})
app.listen(2700,()=>{

    console.log("App is listening at port 2700!!!!")
})