const {home,about,contact, info, careers} = require('../controllers/controllers.js')



const express = require('express')

const router = express.Router()

router.get('/home',home)

router.get('/about',about)

router.get('/contact',contact)

router.get('/info',info)

router.get('/careers',careers)

module.exports = router