const path = require('path')

const home = (req,res)=>{

console.log(path.join(process.cwd(),'public','home.html'))
   res.sendFile(path.join(process.cwd(),'public','home.html'))
}

const about = (req,res)=>{
    
    res.sendFile(path.join(process.cwd(),'public','about.html'))
}

const contact = (req,res)=>{

   res.sendFile(path.join(process.cwd(),'public','contact.html'))
}

const info = (req,res)=>{

   res.render('info.ejs')
}

const careers = (req,res)=>{

   res.render('careers.ejs')
}
 
module.exports = {home,about,contact,info,careers}