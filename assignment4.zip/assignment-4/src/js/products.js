/**
 * products.js
 *
 * The store's products are defined as an Array of product Objects.
 * Each product Object includes the following properties:
 *
 *  - id: String, a unique product identifier (e.g., "P1", "P2")
 *  - title: String, a short name for the product (e.g., "Gingerbread Cookie")
 *  - description: String, a description of the product
 *  - price: Number, the unit price of the item in whole cents (e.g., 100 = $1.00, 5379 = $53.79)
 *  - discontinued: Boolean, whether or not the product has been discontinued
 *  - categories: Array, the category id or ids to which this product belongs (e.g., ["c1"] or ["c1", "c2"])
 */

 window.products = [
  {
    id: "10123",
    title: "Milk",
    description:
      "Milk is a nutrient-rich liquid food produced by the mammary glands of mammals. It is the primary source of nutrition for young mammals before they are able to digest solid food. Immune factors and immune-modulating components in milk contribute to milk immunity. ",
    price: 450,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "10124",
    title: "butter",
    description:
      "Butter is a dairy product made from the fat and protein components of churned cream. It is a semi-solid emulsion at room temperature, consisting of approximately 80% butterfat. It is used at room temperature as a spread, melted as a condiment, and used as a fat in baking, sauce-making, pan frying, and other cooking procedures. ",
    price: 576,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "10125",
    title: "vegetables",
    description:
      "Vegetables are parts of plants that are consumed by humans or other animals as food. The original meaning is still commonly used and is applied to plants collectively to refer to all edible plant matter, including the flowers, fruits, stems, leaves, roots, and seeds. An alternative definition of the term is applied somewhat arbitrarily, often by culinary and cultural tradition.",
    price: 200,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "10126",
    title: "fruits",
    description:
      "Fruits are the means by which flowering plants (also known as angiosperms) disseminate their seeds. Edible fruits in particular have long propagated using the movements of humans and animals in a symbiotic relationship that is the means for seed dispersal for the one group and nutrition for the other;",
    price: 397,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "10127",
    title: "utensils",
    description:
      "A kitchen utensil is a small hand held tool used for food preparation. Common kitchen tasks include cutting food items to size, heating food on an open fire, A variety of eating utensils have been used by people to aid eating when dining. Most societies traditionally use bowls or dishes to contain food to be eaten",
    price: 2500,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "10128",
    title: "spices",
    description:
      "A spice is a seed, fruit, root, bark, or other plant substance primarily used for flavoring or coloring food. Spices are distinguished from herbs, which are the leaves, flowers, or stems of plants used for flavoring or as a garnish. Spices are sometimes used in medicine, religious rituals, cosmetics or perfume production.",
    price: 400,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "11123",
    title: 'shoes"',
    description:
      "A shoe is an item of footwear intended to protect and comfort the human foot. Shoes are also used as an item of decoration and fashion. The design of shoes has varied enormously through time and from culture to culture, with form originally being tied to function.",
    price: 8500,
    discontinued: false,
    categories: ["SNK-spo", "SNK-clo"]
  },

  {
    id: "11124",
    title: "chess",
    description:
      "Chess is a board game played between two players. It is sometimes called Western chess or international chess to distinguish it from related games such as xiangqi and shogi. The current form of the game emerged in Spain and the rest of Southern Europe during the second half of the 15th century after evolving from chaturanga, a similar but much older game of Indian origin.",
    price: 5900,
    discontinued: false,
    categories: ["SNK-spo"]
  },

  {
    id: "11125",
    title: "Boxing",
    description:
      "Boxing (also known as Western boxing or pugilism) is a combat sport in which two people, usually wearing protective gloves and other protective equipment such as hand wraps and mouthguards, throw punches at each other for a predetermined amount of time in a boxing ring",
    price: 17998,
    discontinued: false,
    categories: ["SNK-spo"]
  },

  {
    id: "11126",
    title: "Balls",
    description:
      "A ball is a round object (usually spherical, but can sometimes be ovoid)[1] with several uses. It is used in ball games, where the play of the game follows the state of the ball as it is hit, kicked or thrown by players. Balls can also be used for simpler activities, such as catch or juggling.",
    price: 600,
    discontinued: false,
    categories: ["SNK-spo"]
  },

  {
    id: "11127",
    title: "Badminton",
    description:
      "Badminton is a racquet sport played using racquets to hit a shuttlecock across a net. Although it may be played with larger teams, the most common forms of the game are singles (with one player per side) and doubles (with two players per side). Badminton is often played as a casual outdoor activity in a yard or on a beach",
    price: 1500,
    discontinued: false,
    categories: ["SNK-spo"]
  },

  {
    id: "11128",
    title: "Swimsuit",
    description:
      "A swimsuit is an item of clothing designed to be worn by people engaging in a water-based activity or water sports, such as swimming, diving and surfing, or sun-orientated activities, such as sun bathing. Different types may be worn by men, women, and children.",
    price: 1600,
    discontinued: false,
    categories: ["SNK-spo"]
  },

  {
    id: "12123",
    title: "Hoodies",
    description:
      "A hoodie (in some cases it is also spelled hoody[1] and alternatively known as a hooded sweatshirt)[2] is a sweatshirt with a hood.[1] Hoodies often include a muff sewn onto the lower front, and (usually) a drawstring to adjust the hood opening. ",
    price: 4500,
    discontinued: false,
    categories: ["SNK-clo"]
  },

  {
    id: "12124",
    title: "Caps",
    description:
      "A cap is a flat headgear, usually with a visor. Caps have crowns that fit very close to the head. They made their first appearance as early as 3,200BC.[1] Caps typically have a visor, or no brim at all.[",
    price: 2000,
    discontinued: false,
    categories: ["SNK-clo"]
  },

  {
    id: "12125",
    title: "Pants",
    description:
      "Trousers (British English), slacks, or pants are an item of clothing that may have originated in Central Asia, worn from the waist to the ankles, covering both legs separately (rather than with cloth extending across both legs as in robes, skirts, and dresses). ",
    price: 4500,
    discontinued: false,
    categories: ["SNK-clo"]
  },

  {
    id: "12126",
    title: "Jeans",
    description:
      "Jeans are a type of pants or trousers made from denim or dungaree cloth. Often the term jeans refers to a particular style of trousers, called blue jean, which were invented by Jacob W. Davis in partnership with Levi Strauss & Co. in 1871[1] and patented by Jacob W. Davis and Levi Strauss on May 20, 1873. Prior to the Levi Strauss patented trousers, the term blue jeans had been long in use for various garments",
    price: 5900,
    discontinued: false,
    categories: ["SNK-clo"]
  },

  {
    id: "12127",
    title: "Socks",
    description:
      "A sock is a piece of clothing worn on the feet and often covering the ankle or some part of the calf. Some types of shoes or boots are typically worn over socks. In ancient times, socks were made from leather or matted animal hair",
    price: 1200,
    discontinued: false,
    categories: ["SNK-clo"]
  },

  {
    id: "12128",
    title: "UnderGarments",
    description:
      "Undergarments or underwear are items of clothing worn beneath outer clothes, usually in direct contact with the skin, although they may comprise more than a single layer. They serve to keep outer garments from being soiled or damaged by bodily excretions, to lessen the friction of outerwear against the skin, to shape the body, and to provide concealment or support for parts of it.",
    price: 1300,
    discontinued: false,
    categories: ["SNK-clo"]
  },

  {
    id: "10456",
    title: "zippers",
    description:
      "A zipper, zip, fly, or zip fastener, formerly known as a clasp locker, is a commonly used device for binding together two edges of fabric or other flexible material. Used in clothing (e.g. jackets and jeans), luggage and other bags, camping gear (e.g. tents and sleeping bags), and many other items, zippers come in a wide range of sizes, shapes, and colors.",
    price: 1000,
    discontinued: false,
    categories: ["SNK-kit"]
  },

  {
    id: "13457",
    title: "Tshirts",
    description:
      "A T-shirt, or tee, is a style of fabric shirt named after the T shape of its body and sleeves. Traditionally, it has short sleeves and a round neckline, known as a crew neck, which lacks a collar. T-shirts are generally made of a stretchy, light, and inexpensive fabric and are easy to clean.",
    price: 2100,
    discontinued: false,
    categories: ["SNK-kit", "SNK-spo"]
  },

  {
    id: "11456",
    title: "Shirts",
    description:
      "A shirt is a cloth garment for the upper body (from the neck to the waist). Originally an undergarment worn exclusively by men, it has become, in American English, a catch-all term for a broad variety of upper-body garments and undergarments.  In British English, a shirt is more specifically a garment with a collar, sleeves with cuffs, and a full vertical opening with buttons or snaps (North Americans would call that a shirt, a specific type of collared shirt).",
    price: 2600,
    discontinued: false,
    categories: ["SNK-spo"]
  },

  {
    id: "11457",
    title: "Dresses",
    description:
      "A dress  is a garment traditionally worn by women or girls consisting of a skirt with an attached bodice (or a matching bodice giving the effect of a one-piece garment).[1] It consists of a top piece that covers the torso and hangs down over the legs. A dress can be any one-piece garment containing a skirt of any length, and can be formal or casual.",
    price: 6000,
    discontinued: false,
    categories: ["SNK-spo"]
  }
];