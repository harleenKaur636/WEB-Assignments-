/********************************************************************************* 
*  WEB322 – Assignment 2
*  I declare that this assignment is my own work in accordance with Seneca  Academic Policy.   
*  No part of this assignment has been copied manually or electronically from any other source 
*  (including web sites) or distributed to other students. 
*  
*  Name: ___Harleen_Kaur___________ Student ID: ____163071210_____ Date: ______03 November 2022__________
********************************************************************************/ 

const express = require('express')

const app = express()

// set the view engine as ejs to use ejs template files

app.set('view engine', 'ejs')

//Require mongoose for Mongo db operations

const mongoose = require('mongoose')

mongoose.connect("mongodb+srv://seneca_Harleen:Kaur03!@cluster0.urlla6b.mongodb.net/?retryWrites=true&w=majority",
{useNewUrlParser: true, 
useUnifiedTopology: true},(error)=>{
    if(error){
        console.log("Mongodb not connected due to the error below!")
        console.log(error)
    }

    else{

        console.log("Mongodb Connected Successfully!!!")
    }
})

// // Create a schema

const BooksSchema = mongoose.Schema({

    book_name : String , 
    publisher_name : String , 
    genre : String , 
    price : Number ,
    publisher_email : String , 

})

// // Create a model for your collections

 const BooksModel = mongoose.model("Books",BooksSchema)

// // Step 3 => Create your first document using BooksModel

// BooksModel.create({

// book_name : "The fault in our stars",
// publisher_name : "John Green",
// genre : "Fiction",
// price: 25,
// publisher_email : "john_green@gmail.com",

// },(error,books_create)=>{

//     if(error){
//         console.log("Books document not created due to error")
//         console.log(error)
//     }
//     else{

//         console.log("Books created successfully as!!!")
//         console.log(books_create)
//     }
// })


// // Read Operation : Display all documents from the collection Books_records in Mongo Db

// BooksModel.find({},(error,all_books)=>{

//     if(error){

//         console.log(error)
//     }

//     else{
//         console.log("Books Documents from Books_Records Collection")
//         console.log(all_books)
//         console.log("========================================")
//     }
// })

// // Find one document using ID

// BooksModel.findById("63627c43c27bd20934b63efa",(error,books_found)=>{


//     if(error){
//         console.log(error)
//     }
//     else{
//         console.log("Book Found using ID")
//         console.log(books_found)
//     }
// })


// // update document using id 

// BooksModel.findByIdAndUpdate("63627c43c27bd20934b63efa",{

// book_name : "Everything Everything",
// publisher_name : "Nicola Yoon",
// genre : "Fiction",
// price : "50",
// publisher_email : "nicola_yoon@gmail.com"


// },(error,books_updated)=>{

//     if(error){
//         console.log(error)
//     }
//     else{
//         console.log("=================Books Document Updated as !!!=============== ")
//         console.log(books_updated)
//     }
// })

// // Delete Document 

// BooksModel.findByIdAndDelete("63627d4b93b177d3ad75ee2b",(error,books_deleted)=>{



//     if(error){
//         console.log(error)
//     }
//     else{
//         console.log("Document deleted successfully as given below !!!")
//         console.log(books_deleted)
//     }
// })



app.get("/all",(req,res)=>{

    BooksModel.find({},(error,all_books)=>{

        if(error){
    
            console.log(error)
        }
    
        else{
            console.log("Books Documents from Books_db Collection")
            console.log(all_books)
            console.log("========================================")
             
            res.render("display.ejs", {books:all_books})
        
        }
    })

})

app.listen(3400,()=>{

    console.log("App is listening at port 3400!!!");
})





